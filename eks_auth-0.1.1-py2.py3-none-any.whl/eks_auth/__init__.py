"""Top-level package for eks_auth."""

__author__ = """Sam Holden"""
__email__ = 'holdens.uk@googlemail.com'
__version__ = '0.1.0'
